let hamburger = document.querySelector(".hamburger");
hamburger.onclick = function(){
  hamburger.classList.toggle("active");
  let navBar = document.querySelector(".navbar");
  navBar.classList.toggle("active");
};