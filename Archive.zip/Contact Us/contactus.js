let hamburger = document.querySelector(".hamburger");
hamburger.onclick = function(){
  hamburger.classList.toggle("active");
  let navBar = document.querySelector(".navbar");
  navBar.classList.toggle("active");
};

var form = document.getElementById('form')
var fullname = document.getElementById('fullname')
var email = document.getElementById('email')
var phone = document.getElementById('phone')
var ramen = document.getElementById('ramen')
var dryramen = document.getElementById('dryramen')
var agreement = document.getElementById('agree')



function checkInput(){
    if(fullname.value == '' || fullname.value.length < 3  || !/^[A-Za-z\s]*$/.test(fullname.value)){
        alert('Invalid Characters!')
    }
    else if(!email.value.endsWith('@gmail.com')){
        alert('Email must ends with @gmail.com!')
    }
    else if(!phone.value.startsWith('08') || phone.value.length > 12 || phone.value.length < 8){
        alert('Invalid phone numbers (8-12 digits and starts with 08)!')
    }
    else if(!ramen.checked && !dryramen.checked){
        alert('Must select at least 1!')
    }
    else if(!agreement.checked){
        alert('Agreement box must be checked!')
    }
    else{
        confirm('Thank You!')
    }
}
