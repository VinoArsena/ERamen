let hamburger = document.querySelector(".hamburger");
hamburger.onclick = function(){
  hamburger.classList.toggle("active");
  let navBar = document.querySelector(".navbar");
  navBar.classList.toggle("active");
};



var slide = document.getElementById("slide");
var slides = ['slide1.png', 'slide2.png', 'slide3.png'], i = 1;

slide.src = slides[0];

function changeSlide(i){
  slide.src = slides[i];
}

setInterval(function(){
  if(i > 2){
    i = 0;
  }
  changeSlide(i);
  i++;
},5000)

